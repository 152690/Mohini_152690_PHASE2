package com.cg.paymentwalletappjdbc.service.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.paymentwalletappjdbc.dao.IPaymentDao;
import com.cg.paymentwalletappjdbc.dao.PaymentDaoImpl;
import com.cg.paymentwalletappjdbc.dto.Wallet;
import com.cg.paymentwalletappjdbc.exception.PaymentException;
import com.cg.paymentwalletappjdbc.service.IPaymentService;
import com.cg.paymentwalletappjdbc.service.PaymentServiceImpl;



public class TestValidation {
	IPaymentService service=new PaymentServiceImpl();
	IPaymentDao dao=new PaymentDaoImpl();
		@Test
		public void CheckForZeroDeposittest() throws PaymentException {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("9595959595");
			dao.createAccount(wallet);
			condition=service.deposit("9595959595", 0.0);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidDepositAmount() throws PaymentException {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("9595959595");
			dao.createAccount(wallet);
			condition=service.deposit("9595959595", 500);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("fd65f46");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			service.validateDetails(wallet);
		}
		
		@Test
		public void CheckForValidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("779494");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("4gfgaff");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}

		@Test (expected=PaymentException.class)
		public void CheckForInvalidUserId() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("moh888@ni");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
			
		}
		
		@Test 
		public void CheckForValidUserId() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
			
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidpassword() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
			
		}
		
		@Test 
		public void CheckForValidPassword() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Mohini");
			wallet.setPhNumber("9595959595");
			wallet.setEmailId("mohini@gmail.com");
			wallet.setUserId("mohini");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
			
		}

}
